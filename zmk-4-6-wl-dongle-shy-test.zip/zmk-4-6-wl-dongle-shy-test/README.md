4-6 wireless with dongle
